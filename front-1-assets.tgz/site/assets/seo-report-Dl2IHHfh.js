import{bo as f}from"./index-DHqgRto2.js";import{d as m}from"./backendPending-Dc_345i-.js";import{u as b}from"./mediaApi-DZraLyi1.js";import{r as u}from"./blogTaxonomy-BXFJfPVp.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const U=f("FileDown",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M12 18v-6",key:"17g6i2"}],["path",{d:"m9 15 3 3 3-3",key:"1npd3o"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const T=f("FileJson",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 12a1 1 0 0 0-1 1v1a1 1 0 0 1-1 1 1 1 0 0 1 1 1v1a1 1 0 0 0 1 1",key:"1oajmo"}],["path",{d:"M14 18a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1 1 1 0 0 1-1-1v-1a1 1 0 0 0-1-1",key:"mpwhp6"}]]),v=(e,o,a,n,l,s,t=4)=>{const r=o.split(/\s+/);let i="",d=0;for(let p=0;p<r.length;p++){const h=i?`${i} ${r[p]}`:r[p];if(e.measureText(h).width>a&&i){if(e.fillText(i,l,s+d*n),i=r[p],d++,d>=t-1){let g=r.slice(p).join(" ");for(;e.measureText(g+"…").width>a&&g.length;)g=g.slice(0,-1);e.fillText(g+"…",l,s+d*n);return}}else i=h}i&&e.fillText(i,l,s+d*n)};async function y({title:e,category:o,url:a}){const s=document.createElement("canvas");s.width=1200,s.height=630;const t=s.getContext("2d"),r=t.createLinearGradient(0,0,1200,630);r.addColorStop(0,"#0e3b2e"),r.addColorStop(1,"#1f6b53"),t.fillStyle=r,t.fillRect(0,0,1200,630),t.fillStyle="#d4a857",t.fillRect(1188,0,12,630),t.fillStyle="rgba(255,255,255,0.06)",t.fillRect(60,60,1068,510),t.strokeStyle="rgba(212,168,87,0.6)",t.lineWidth=2,t.strokeRect(60,60,1068,510),t.fillStyle="#d4a857",t.font="bold 28px system-ui, -apple-system, 'Segoe UI', Tahoma, sans-serif",t.textAlign="right",t.direction="rtl",t.fillText("مؤسسة اليسر الخيرية — المنصورة",1100,120),t.fillStyle="#d4a857";const i=o;t.font="bold 22px system-ui, -apple-system, 'Segoe UI', Tahoma, sans-serif";const d=t.measureText(i).width+40;return t.fillRect(1100-d,150,d,44),t.fillStyle="#0e3b2e",t.fillText(i,1080,182),t.fillStyle="#ffffff",t.font="900 56px system-ui, -apple-system, 'Segoe UI', Tahoma, sans-serif",v(t,e,1e3,70,1100,280,4),t.fillStyle="rgba(255,255,255,0.85)",t.font="bold 22px system-ui, -apple-system, 'Segoe UI', Tahoma, sans-serif",t.textAlign="left",t.direction="ltr",t.fillText(a,100,540),t.fillStyle="#d4a857",t.font="bold 20px system-ui, -apple-system, 'Segoe UI', Tahoma, sans-serif",t.textAlign="right",t.direction="rtl",t.fillText("مؤسسة اليسر الخيرية · المنصورة",1100,540),s.toDataURL("image/jpeg",.9)}function E(e,o){const a=document.createElement("a");a.href=e,a.download=o,document.body.appendChild(a),a.click(),document.body.removeChild(a)}const w=e=>e.toLowerCase().replace(/[^\w.-]+/g,"-").replace(/^-+|-+$/g,"").slice(0,60)||"file";async function x(e,o,a="blog"){const n=o.includes(".")?o.split(".").pop():"jpg",l=`${w(o.replace(/\.[^.]+$/,""))}.${n}`;try{const s=await b(e,l,a);if(!s.url)throw new Error("لم يرجع السيرفر رابط الصورة");return s.url}catch(s){throw new Error(m(s,"POST /media"))}}async function R(e){const o=await y({title:e.title,category:e.category,url:`elyusr.org/blog/${e.slug}`}),a=await(await fetch(o)).blob();return x(a,`og-${e.slug}.jpg`,"og")}function k(e){const a=`https://elyusr.org/blog/${e.slug}`;return{"@context":"https://schema.org","@type":"Article",headline:e.ar.title,description:e.ar.excerpt,image:e.image?[e.image]:[],datePublished:e.date,dateModified:e.date,inLanguage:"ar-EG",articleSection:e.category?.ar,keywords:(e.ar.tags||[]).join(", "),mainEntityOfPage:{"@type":"WebPage","@id":a},author:{"@type":"Organization",name:"مؤسسة اليسر الخيرية"},publisher:{"@type":"Organization",name:"مؤسسة اليسر الخيرية"}}}function $(e){const o=k(e),a=[];(!o.headline||o.headline.length<10)&&a.push({field:"headline",level:"error",message:"العنوان قصير أو فاضي."}),o.headline&&o.headline.length>110&&a.push({field:"headline",level:"warn",message:"العنوان طويل جدًا (>110 حرف)."}),(!o.description||o.description.length<50)&&a.push({field:"description",level:"warn",message:"وصف قصير — اكتب 80–170 حرف."}),(!o.image||o.image.length===0)&&a.push({field:"image",level:"error",message:"Schema بدون صورة (og:image مفقود)."}),o.datePublished?isNaN(Date.parse(o.datePublished))&&a.push({field:"datePublished",level:"error",message:"تاريخ النشر صياغته غلط."}):a.push({field:"datePublished",level:"error",message:"ناقص datePublished."}),o.author?.name||a.push({field:"author",level:"error",message:"ناقص author.name."}),o.publisher?.name||a.push({field:"publisher",level:"error",message:"ناقص publisher.name."}),o.mainEntityOfPage?.["@id"]||a.push({field:"mainEntityOfPage",level:"error",message:"ناقص mainEntityOfPage."});try{JSON.parse(JSON.stringify(o))}catch{a.push({field:"json",level:"error",message:"فشل serialization للـ JSON-LD."})}return a}const z=(e,o="https://elyusr.org")=>{const a=u(e,"ar"),n=e.ar.title.length,l=e.ar.excerpt.length,s=e.ar.tags?.length??0,t=!!e.image,r=!!e.category?.ar,i=`${o}/blog/${e.slug}`;let d=0;a.words>=600?d+=25:a.words>=300&&(d+=15),n>=30&&n<=70&&(d+=15),l>=80&&l<=170&&(d+=15),s>=3&&(d+=10),t&&(d+=15),d+=10,r&&(d+=10);const p=[{name:"WordCount ≥ 600",ok:a.words>=600,advice:a.words<600?`أضِف ${600-a.words} كلمة على الأقل.`:void 0},{name:"Title length 30–70",ok:n>=30&&n<=70,advice:n<30?"العنوان قصير — أَطِله.":n>70?"العنوان طويل — اختصره.":void 0},{name:"Description length 80–170",ok:l>=80&&l<=170,advice:l<80?"الوصف قصير.":l>170?"الوصف طويل.":void 0},{name:"Tags ≥ 3",ok:s>=3,advice:s<3?"أضِف وسوماً أكثر.":void 0},{name:"OG image present",ok:t,advice:t?void 0:"ولّد صورة OG."},{name:"Category set",ok:r},{name:"Article + Breadcrumb JSON-LD",ok:!0}];return{slug:e.slug,title:e.ar.title,url:i,score:d,words:a.words,minutes:a.minutes,titleLen:n,descLen:l,tagsCount:s,hasOg:t,hasCategory:r,signals:p,schemaIssues:$(e),openGraph:{"og:title":e.ar.title,"og:description":e.ar.excerpt,"og:image":e.image,"og:url":i,"og:type":"article","og:locale":"ar_EG","article:section":e.category.ar,"article:tag":(e.ar.tags||[]).join(", ")},generatedAt:new Date().toISOString()}},F=e=>{const o=JSON.stringify(e,null,2),a=new Blob(["\uFEFF"+o],{type:"application/json;charset=utf-8"}),n=document.createElement("a");n.href=URL.createObjectURL(a),n.download=`seo-${e.slug}.json`,n.click(),URL.revokeObjectURL(n.href)},c=e=>String(e??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"),C=e=>{const o=e.score>=85?"#10b981":e.score>=60?"#f59e0b":"#dc2626",a=e.signals.map(r=>`
        <tr>
          <td class="ok"><span class="${r.ok?"tick":"cross"}">${r.ok?"✓":"✗"}</span></td>
          <td><b>${c(r.name)}</b></td>
          <td class="advice">${c(r.advice||"—")}</td>
        </tr>`).join(""),n=e.schemaIssues.length?e.schemaIssues.map(r=>`
        <tr>
          <td><span class="lvl ${r.level}">${c(r.level.toUpperCase())}</span></td>
          <td><code>${c(r.field)}</code></td>
          <td>${c(r.message)}</td>
        </tr>`).join(""):'<tr><td colspan="3" class="ok-row">لا توجد مشكلات — السكيمة صحيحة.</td></tr>',l=Object.entries(e.openGraph).map(([r,i])=>`
      <tr><th><code>${c(r)}</code></th><td>${c(i)}</td></tr>`).join(""),s=`<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8" />
<title>تقرير SEO — ${c(e.title||e.slug)}</title>
<style>
  @page { size: A4; margin: 18mm; }
  :root {
    --ink:#0f172a; --muted:#64748b; --border:#e2e8f0;
    --bg:#ffffff; --card:#f8fafc; --accent:${o};
  }
  * { box-sizing: border-box; }
  html, body { margin:0; padding:0; background:var(--bg); color:var(--ink); }
  body {
    font-family: "Cairo", "Tajawal", "Noto Naskh Arabic", "IBM Plex Sans Arabic",
                 "Segoe UI", "Tahoma", "Arial", system-ui, sans-serif;
    font-size: 12pt; line-height: 1.7; direction: rtl;
  }
  header { display:flex; justify-content:space-between; align-items:flex-start; gap:16px;
           border-bottom: 2px solid var(--border); padding-bottom: 12px; margin-bottom: 16px; }
  h1 { font-size: 18pt; margin: 0 0 4px; color:#0b3d2e; }
  h2 { font-size: 13pt; margin: 18px 0 8px; color:#0b3d2e; border-bottom:1px solid var(--border); padding-bottom: 4px; }
  .meta { color: var(--muted); font-size: 10pt; }
  .url { direction: ltr; unicode-bidi: bidi-override; word-break: break-all; }
  .score-badge {
    background: var(--accent); color:#fff; padding: 14px 18px; border-radius: 12px;
    text-align:center; min-width: 120px;
  }
  .score-badge .n { font-size: 26pt; font-weight: 800; line-height: 1; }
  .score-badge .l { font-size: 9pt; opacity: .9; letter-spacing: .04em; }
  .stats { display:grid; grid-template-columns:repeat(3,1fr); gap:8px; margin: 8px 0 16px; }
  .stat { background: var(--card); border:1px solid var(--border); border-radius: 8px; padding: 8px 10px; }
  .stat b { display:block; font-size: 10pt; color: var(--muted); font-weight:600; }
  .stat span { font-size: 14pt; font-weight: 800; color: var(--ink); }
  table { width: 100%; border-collapse: collapse; font-size: 11pt; }
  th, td { border: 1px solid var(--border); padding: 6px 9px; vertical-align: top; text-align: start; }
  th { background: var(--card); font-weight: 700; }
  td.ok { width: 36px; text-align:center; }
  td.advice { color: var(--muted); }
  .tick { color:#16a34a; font-weight: 800; }
  .cross { color:#dc2626; font-weight: 800; }
  .ok-row { color:#16a34a; text-align:center; font-weight: 700; }
  .lvl { display:inline-block; padding: 2px 6px; border-radius: 4px; font-size: 9pt; font-weight: 800; }
  .lvl.error { background:#fee2e2; color:#991b1b; }
  .lvl.warning { background:#fef3c7; color:#92400e; }
  code { font-family: "JetBrains Mono", "Cairo", monospace; direction: ltr; unicode-bidi: bidi-override; }
  .og th { width: 28%; }
  .og td { direction: ltr; unicode-bidi: bidi-override; word-break: break-all; }
  .footer { margin-top: 18px; font-size: 9pt; color: var(--muted); text-align:center; }
  @media print { .no-print { display: none !important; } }
  .no-print {
    position: sticky; top: 0; background: #0b3d2e; color:#fff;
    padding: 8px 14px; display:flex; justify-content:space-between; gap:12px;
    margin: -18mm -18mm 18px; border-radius: 0;
  }
  .no-print button { background:#fff; color:#0b3d2e; border:0; padding:6px 14px;
                     border-radius: 6px; font-weight: 800; cursor:pointer; }
</style>
</head>
<body>
  <div class="no-print">
    <span>اضغط طباعة ثم اختر «حفظ كـ PDF» — يدعم العربية بالكامل.</span>
    <span>
      <button onclick="window.print()">طباعة / حفظ PDF</button>
    </span>
  </div>

  <header>
    <div>
      <h1>تقرير تدقيق SEO — ${c(e.title||e.slug)}</h1>
      <div class="meta">المعرّف: <code>${c(e.slug)}</code></div>
      <div class="meta">الرابط: <span class="url">${c(e.url)}</span></div>
      <div class="meta">تاريخ التوليد: ${c(e.generatedAt)}</div>
    </div>
    <div class="score-badge">
      <div class="n">${e.score}<span style="font-size:14pt">/100</span></div>
      <div class="l">SEO SCORE</div>
    </div>
  </header>

  <div class="stats">
    <div class="stat"><b>عدد الكلمات</b><span>${e.words}</span></div>
    <div class="stat"><b>زمن القراءة</b><span>${e.minutes} د</span></div>
    <div class="stat"><b>عدد الوسوم</b><span>${e.tagsCount}</span></div>
    <div class="stat"><b>طول العنوان</b><span>${e.titleLen}</span></div>
    <div class="stat"><b>طول الوصف</b><span>${e.descLen}</span></div>
    <div class="stat"><b>صورة OG</b><span>${e.hasOg?"✓":"✗"}</span></div>
  </div>

  <h2>الإشارات (Signals)</h2>
  <table>
    <thead><tr><th>الحالة</th><th>المعيار</th><th>الملاحظات</th></tr></thead>
    <tbody>${a}</tbody>
  </table>

  <h2>مشكلات السكيمة (JSON-LD)</h2>
  <table>
    <thead><tr><th>المستوى</th><th>الحقل</th><th>الرسالة</th></tr></thead>
    <tbody>${n}</tbody>
  </table>

  <h2>وسوم Open Graph</h2>
  <table class="og">
    <tbody>${l}</tbody>
  </table>

  <div class="footer">© مؤسسة اليُسر الخيرية — تم التوليد بواسطة لوحة تحكم المدوّنة.</div>

  <script>
    // Auto-open print dialog after fonts load for fastest path to "Save as PDF"
    window.addEventListener("load", function () {
      setTimeout(function () { try { window.print(); } catch (e) {} }, 350);
    });
  <\/script>
</body>
</html>`,t=window.open("","_blank","noopener,noreferrer,width=900,height=1100");if(!t){const r=new Blob(["\uFEFF"+s],{type:"text/html;charset=utf-8"}),i=document.createElement("a");i.href=URL.createObjectURL(r),i.download=`seo-${e.slug}.html`,i.click(),URL.revokeObjectURL(i.href);return}t.document.open(),t.document.write(s),t.document.close()},P=e=>{const o=t=>`"${String(t??"").replace(/"/g,'""')}"`,n=[["Field","Value"],["slug",e.slug],["title",e.title],["url",e.url],["score",e.score],["words",e.words],["minutes",e.minutes],["title_length",e.titleLen],["description_length",e.descLen],["tags_count",e.tagsCount],["has_og",e.hasOg?"yes":"no"],["has_category",e.hasCategory?"yes":"no"],["generated_at",e.generatedAt],[],["Signal","OK","Advice"],...e.signals.map(t=>[t.name,t.ok?"yes":"no",t.advice||""]),[],["Schema Level","Field","Message"],...e.schemaIssues.map(t=>[t.level,t.field,t.message]),[],["OG Key","OG Value"],...Object.entries(e.openGraph).map(([t,r])=>[t,r])].map(t=>t.map(o).join(",")).join(`\r
`),l=new Blob(["\uFEFF"+n],{type:"text/csv;charset=utf-8"}),s=document.createElement("a");s.href=URL.createObjectURL(l),s.download=`seo-${e.slug}.csv`,s.click(),URL.revokeObjectURL(s.href)};export{U as F,T as a,z as b,E as c,P as d,F as e,C as f,R as g,y as h,$ as l};
