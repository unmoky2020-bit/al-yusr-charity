import{cG as o}from"./index-CYtZctlB.js";import{h as t,i as r,p as s}from"./index-CXHAiFMv.js";function i(){!t.current&&r();const[e]=o.useState(s.current);return e}export{i as u};
