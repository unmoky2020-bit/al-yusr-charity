const a="/assets/yusr-ramadan-box-Ctw6XESi.png";export{a as y};
