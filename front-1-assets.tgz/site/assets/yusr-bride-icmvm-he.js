const s="/assets/yusr-bride-B8LST6TU.png";export{s as b};
