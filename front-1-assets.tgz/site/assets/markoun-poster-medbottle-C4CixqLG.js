const t="/assets/markoun-poster-medbottle-DZIJUkCf.png";export{t as p};
