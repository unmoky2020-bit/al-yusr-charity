const e={waqf:"/farm",shelter:"/setr",water:"/water",medical:"/medical",takrim:"/takrim",nurseries:"/nurseries",mosques:"/mosques"};export{e as P};
