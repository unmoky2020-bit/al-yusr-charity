import{db as c,cH as o}from"./index-DWVO5E7w.js";import{d as r}from"./AdminLayout-BP_etMpp.js";function u(){const{access:s}=c();return o.useCallback(a=>r(s,a),[s])}export{u};
