const e="/assets/tiny_face_detector_model-weights_manifest-Cc0UMsZK.json";export{e as default};
