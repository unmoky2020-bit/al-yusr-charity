const s="/assets/program-orphans-BraIEzff.jpg",a="/assets/program-health-Dl9eN7ZX.webp";export{a as h,s as o};
