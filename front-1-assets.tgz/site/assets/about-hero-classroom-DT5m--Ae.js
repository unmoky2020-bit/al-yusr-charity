const o="/assets/about-hero-classroom-D9V1PUSw.jpg";export{o as a};
