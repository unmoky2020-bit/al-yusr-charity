const a="/assets/qurbani-meat-quality-Dul-gXpZ.webp";export{a as q};
