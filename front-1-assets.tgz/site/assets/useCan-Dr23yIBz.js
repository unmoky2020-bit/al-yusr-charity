import{db as c,cH as o}from"./index-CEH21SH2.js";import{d as r}from"./AdminLayout-DvjV7oPC.js";function u(){const{access:s}=c();return o.useCallback(a=>r(s,a),[s])}export{u};
