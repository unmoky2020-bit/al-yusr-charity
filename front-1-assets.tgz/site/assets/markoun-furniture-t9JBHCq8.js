const s="/assets/program-water-new-BnJmaVSC.jpg",o="/assets/program-food-new-Dxt8A3MS.jpg",a="/assets/markoun-furniture-DKOJJg5t.webp";export{o as f,a as m,s as w};
