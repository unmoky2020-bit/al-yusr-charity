const s="/assets/yusr-water-D3bKDtdJ.png";export{s as p};
