const s="/assets/yusr-orphans-meals-BdpuRBFy.webp";export{s as m};
