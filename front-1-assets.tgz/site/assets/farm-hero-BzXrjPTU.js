const s="/assets/farm-hero-Wsk9XZD2.jpg";export{s as i};
