import{cG as o}from"./index-JJbt3h9W.js";import{h as t,i as r,p as s}from"./index-CXHAiFMv.js";function i(){!t.current&&r();const[e]=o.useState(s.current);return e}export{i as u};
