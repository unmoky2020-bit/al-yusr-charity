const s="/assets/brand-truck--6Ve7vxD.jpg",r="/assets/brand-girl-orange-DipewnS8.jpg";export{r as g,s as t};
