const s="/assets/brand-bags-CI099YhY.jpg";export{s as b};
