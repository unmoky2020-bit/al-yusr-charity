import{da as c,cG as o}from"./index-CYtZctlB.js";import{d as r}from"./AdminLayout-B6rof3Oi.js";function u(){const{access:s}=c();return o.useCallback(a=>r(s,a),[s])}export{u};
