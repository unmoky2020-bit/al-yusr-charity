import{bo as o}from"./index-DWVO5E7w.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a=o("Minus",[["path",{d:"M5 12h14",key:"1ays0h"}]]);export{a as M};
