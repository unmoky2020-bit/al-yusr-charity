const e="/assets/markoun-puzzle-Dn8GvANP.webp";export{e as m};
