const s="/assets/poster-education-71-9IpU2.png";export{s as p};
