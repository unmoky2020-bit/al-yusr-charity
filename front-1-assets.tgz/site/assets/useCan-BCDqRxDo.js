import{db as c,cH as o}from"./index-DHqgRto2.js";import{d as r}from"./AdminLayout-DI3hKQ9t.js";function u(){const{access:s}=c();return o.useCallback(a=>r(s,a),[s])}export{u};
