import{cb as s,a7 as a}from"./index-JJbt3h9W.js";const t=()=>s.jsx(a,{to:"/admin/users?tab=permissions",replace:!0});export{t as default};
