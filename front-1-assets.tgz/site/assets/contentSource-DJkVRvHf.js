function e(n){const t=String(n??"").trim().toLowerCase();return t==="static"?"static":t==="auto"?"auto":"api"}const o=e(void 0),a=o!=="static";export{o as C,a as u};
