const e="/assets/tiny_face_detector_model-C4Zmc5xe.bin";export{e as default};
