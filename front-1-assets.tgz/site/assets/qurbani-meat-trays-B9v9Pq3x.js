const a="/assets/qurbani-meat-trays-e_fBh8jy.jpg";export{a as m};
