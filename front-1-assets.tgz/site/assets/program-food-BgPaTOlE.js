const o="/assets/program-food-DGr6CXro.jpg";export{o as f};
