const n=[],e=["mansoura"],E=s=>n.includes(s),o=s=>e.includes(s);export{E as a,o as i};
