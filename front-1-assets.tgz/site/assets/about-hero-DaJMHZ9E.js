const s="/assets/about-hero-DRSUJeaj.jpg";export{s as i};
