const o="/assets/markoun-poster-clothes-DS_9MaKO.webp";export{o as m};
