import{S as s}from"./sparkles-BNeqMxhC.js";import{Z as l}from"./zap-DVrs6EPA.js";import{W as M}from"./wind-CRejGhkw.js";import{W as C}from"./wheat-yODTkEPt.js";import{W as v}from"./wallet-B47I8mOh.js";import{bo as a,aK as u,aJ as L,aE as S,aC as x,aA as g,ah as H,a2 as h,a1 as w,X as B,S as A,R as T,Q as V,s as b,p as P,l as z,k as D,j,B as o}from"./index-CYtZctlB.js";import{U as I}from"./utensils-crossed-D73Ah7Lk.js";import{U as c}from"./utensils-CHTOdOq3.js";import{U}from"./users-BYkLkFtg.js";import{T as q}from"./truck-CprcSt10.js";import{T as G}from"./trending-up-YR84Q35w.js";import{T as E,D as W,B as Z}from"./thermometer-C3LM5zrZ.js";import{S as O}from"./sun-Cw_4-cj6.js";import{S as k}from"./stethoscope-BD6fHK8g.js";import{S as F}from"./star-BL5zQH_f.js";import{S as N}from"./smartphone-D7pfa6C0.js";import{S as R}from"./shirt-Bjh8Ffkl.js";import{S as J}from"./shield-alert-EsPH5gVy.js";import{S as K}from"./shield-gCKx7zs-.js";import{S as Q}from"./scale-tRJ_YlP9.js";import{R as X}from"./recycle-D0COmSzX.js";import{P as _}from"./phone-call-B50ymZlQ.js";import{P as Y}from"./pencil-Bo_8sC8B.js";import{P as $}from"./package-yJtYTXRT.js";import{M as a1}from"./moon-2nKuszS1.js";import{M as r1}from"./megaphone-BRvFqZmW.js";import{L as o1}from"./list-checks-_OsTtgLP.js";import{L as t1}from"./lightbulb-hA2qEuzQ.js";import{L as e1}from"./leaf-BOC9wDx0.js";import{L as s1}from"./layers-DKVk22KX.js";import{L as m1}from"./laptop-B5kP7i-7.js";import{L as p1}from"./landmark-CfoEalJQ.js";import{I as i1}from"./image-CfZJO3Tk.js";import{H as h1,A as c1}from"./hospital-q1Uhbzav.js";import{H as k1}from"./house-C-Bj_eIR.js";import{H as d1}from"./heart-pulse-DysQ3xYV.js";import{H as y1}from"./heart-handshake-0SSxPFZI.js";import{H as n1}from"./hammer-vCzZGlH-.js";import{G as d}from"./graduation-cap-BYWbrlSs.js";import{E as f1}from"./earth-D4Icx8Rx.js";import{G as l1}from"./globe-C6Xbhft5.js";import{G as M1}from"./gift-CloLCfXQ.js";import{F as C1}from"./flame-BdnMc7Kl.js";import{F as r}from"./file-check-2-qXbhknE-.js";import{E as v1}from"./eye-DUIX_rb3.js";import{D as y}from"./droplets-By2S-geq.js";import{C as u1}from"./credit-card-wzkbMHhA.js";import{C as L1}from"./compass-Bjo7wKsO.js";import{C as n}from"./coins-DIVMYYpC.js";import{C as S1}from"./clock-CONhnhwT.js";import{C as x1}from"./car-DABOsT_u.js";import{C as g1}from"./camera-CrAcuPFw.js";import{C as H1}from"./calendar-days-BcTrQBsZ.js";import{C as w1}from"./calendar-CHu2y3OC.js";import{C as B1}from"./calculator-OjwLNcfn.js";import{B as A1}from"./building-DxA29lVM.js";import{B as T1}from"./boxes-Dji9kxAg.js";import{B as V1}from"./beef-BGFW3MWd.js";import{C as b1}from"./chart-column-BQ_giLdG.js";import{B as P1}from"./banknote-D_LY-7Qj.js";import{B as z1}from"./baby-CawNFduo.js";import{A as D1}from"./award-CKKur9Z_.js";import{A as j1}from"./archive-D0qX1vwD.js";import{A as I1}from"./activity-CsD4Ljoa.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const U1=a("Bus",[["path",{d:"M8 6v6",key:"18i7km"}],["path",{d:"M15 6v6",key:"1sg6z9"}],["path",{d:"M2 12h19.6",key:"de5uta"}],["path",{d:"M18 18h3s.5-1.7.8-2.8c.1-.4.2-.8.2-1.2 0-.4-.1-.8-.2-1.2l-1.4-5C20.1 6.8 19.1 6 18 6H4a2 2 0 0 0-2 2v10h3",key:"1wwztk"}],["circle",{cx:"7",cy:"18",r:"2",key:"19iecd"}],["path",{d:"M9 18h5",key:"lrx6i"}],["circle",{cx:"16",cy:"18",r:"2",key:"1v4tcr"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const q1=a("Church",[["path",{d:"M10 9h4",key:"u4k05v"}],["path",{d:"M12 7v5",key:"ma6bk"}],["path",{d:"M14 22v-4a2 2 0 0 0-4 0v4",key:"1pdhuj"}],["path",{d:"M18 22V5.618a1 1 0 0 0-.553-.894l-4.553-2.277a2 2 0 0 0-1.788 0L6.553 4.724A1 1 0 0 0 6 5.618V22",key:"1rkokr"}],["path",{d:"m18 7 3.447 1.724a1 1 0 0 1 .553.894V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9.618a1 1 0 0 1 .553-.894L6 7",key:"1w6esw"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const G1=a("Cross",[["path",{d:"M4 9a2 2 0 0 0-2 2v2a2 2 0 0 0 2 2h4a1 1 0 0 1 1 1v4a2 2 0 0 0 2 2h2a2 2 0 0 0 2-2v-4a1 1 0 0 1 1-1h4a2 2 0 0 0 2-2v-2a2 2 0 0 0-2-2h-4a1 1 0 0 1-1-1V4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4a1 1 0 0 1-1 1z",key:"1xbrqy"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const E1=a("Droplet",[["path",{d:"M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C6 11.1 5 13 5 15a7 7 0 0 0 7 7z",key:"c7niix"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const W1=a("Drumstick",[["path",{d:"M15.4 15.63a7.875 6 135 1 1 6.23-6.23 4.5 3.43 135 0 0-6.23 6.23",key:"1dtqwm"}],["path",{d:"m8.29 12.71-2.6 2.6a2.5 2.5 0 1 0-1.65 4.65A2.5 2.5 0 1 0 8.7 18.3l2.59-2.59",key:"1oq1fw"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Z1=a("Handshake",[["path",{d:"m11 17 2 2a1 1 0 1 0 3-3",key:"efffak"}],["path",{d:"m14 14 2.5 2.5a1 1 0 1 0 3-3l-3.88-3.88a3 3 0 0 0-4.24 0l-.88.88a1 1 0 1 1-3-3l2.81-2.81a5.79 5.79 0 0 1 7.06-.87l.47.28a2 2 0 0 0 1.42.25L21 4",key:"9pr0kb"}],["path",{d:"m21 3 1 11h-2",key:"1tisrp"}],["path",{d:"M3 3 2 14l6.5 6.5a1 1 0 1 0 3-3",key:"1uvwmv"}],["path",{d:"M3 4h8",key:"1ep09j"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const O1=a("Map",[["path",{d:"M14.106 5.553a2 2 0 0 0 1.788 0l3.659-1.83A1 1 0 0 1 21 4.619v12.764a1 1 0 0 1-.553.894l-4.553 2.277a2 2 0 0 1-1.788 0l-4.212-2.106a2 2 0 0 0-1.788 0l-3.659 1.83A1 1 0 0 1 3 19.381V6.618a1 1 0 0 1 .553-.894l4.553-2.277a2 2 0 0 1 1.788 0z",key:"169xi5"}],["path",{d:"M15 5.764v15",key:"1pn4in"}],["path",{d:"M9 3.236v15",key:"1uimfh"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const F1=a("Newspaper",[["path",{d:"M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-2 2Zm0 0a2 2 0 0 1-2-2v-9c0-1.1.9-2 2-2h2",key:"7pis2x"}],["path",{d:"M18 14h-8",key:"sponae"}],["path",{d:"M15 18h-5",key:"95g1m2"}],["path",{d:"M10 6h8v4h-8V6Z",key:"smlsk5"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const N1=a("PenTool",[["path",{d:"M15.707 21.293a1 1 0 0 1-1.414 0l-1.586-1.586a1 1 0 0 1 0-1.414l5.586-5.586a1 1 0 0 1 1.414 0l1.586 1.586a1 1 0 0 1 0 1.414z",key:"nt11vn"}],["path",{d:"m18 13-1.375-6.874a1 1 0 0 0-.746-.776L3.235 2.028a1 1 0 0 0-1.207 1.207L5.35 15.879a1 1 0 0 0 .776.746L13 18",key:"15qc1e"}],["path",{d:"m2.3 2.3 7.286 7.286",key:"1wuzzi"}],["circle",{cx:"11",cy:"11",r:"2",key:"xmgehs"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const R1=a("PiggyBank",[["path",{d:"M19 5c-1.5 0-2.8 1.4-3 2-3.5-1.5-11-.3-11 5 0 1.8 0 3 2 4.5V20h4v-2h3v2h4v-4c1-.5 1.7-1 2-2h2v-4h-2c0-1-.5-1.5-1-2V5z",key:"1ivx2i"}],["path",{d:"M2 9v1c0 1.1.9 2 2 2h1",key:"nm575m"}],["path",{d:"M16 11h.01",key:"xkw8gn"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const J1=a("School",[["path",{d:"M14 22v-4a2 2 0 1 0-4 0v4",key:"hhkicm"}],["path",{d:"m18 10 3.447 1.724a1 1 0 0 1 .553.894V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-7.382a1 1 0 0 1 .553-.894L6 10",key:"1xqip1"}],["path",{d:"M18 5v17",key:"1sw6gf"}],["path",{d:"m4 6 7.106-3.553a2 2 0 0 1 1.788 0L20 6",key:"9d2mlk"}],["path",{d:"M6 5v17",key:"1xfsm0"}],["circle",{cx:"12",cy:"9",r:"2",key:"1092wv"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const K1=a("Soup",[["path",{d:"M12 21a9 9 0 0 0 9-9H3a9 9 0 0 0 9 9Z",key:"4rw317"}],["path",{d:"M7 21h10",key:"1b0cd5"}],["path",{d:"M19.5 12 22 6",key:"shfsr5"}],["path",{d:"M16.25 3c.27.1.8.53.75 1.36-.06.83-.93 1.2-1 2.02-.05.78.34 1.24.73 1.62",key:"rpc6vp"}],["path",{d:"M11.25 3c.27.1.8.53.74 1.36-.05.83-.93 1.2-.98 2.02-.06.78.33 1.24.72 1.62",key:"1lf63m"}],["path",{d:"M6.25 3c.27.1.8.53.75 1.36-.06.83-.93 1.2-1 2.02-.05.78.34 1.24.74 1.62",key:"97tijn"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Q1=a("Syringe",[["path",{d:"m18 2 4 4",key:"22kx64"}],["path",{d:"m17 7 3-3",key:"1w1zoj"}],["path",{d:"M19 9 8.7 19.3c-1 1-2.5 1-3.4 0l-.6-.6c-1-1-1-2.5 0-3.4L15 5",key:"1exhtz"}],["path",{d:"m9 11 4 4",key:"rovt3i"}],["path",{d:"m5 19-3 3",key:"59f2uf"}],["path",{d:"m14 4 6 6",key:"yqp9t2"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const X1=a("Tent",[["path",{d:"M3.5 21 14 3",key:"1szst5"}],["path",{d:"M20.5 21 10 3",key:"1310c3"}],["path",{d:"M15.5 21 12 15l-3.5 6",key:"1ddtfw"}],["path",{d:"M2 21h20",key:"1nyx9w"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _1=a("Timer",[["line",{x1:"10",x2:"14",y1:"2",y2:"2",key:"14vaq8"}],["line",{x1:"12",x2:"15",y1:"14",y2:"11",key:"17fdiu"}],["circle",{cx:"12",cy:"14",r:"8",key:"1e1u0o"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Y1=a("Trees",[["path",{d:"M10 10v.2A3 3 0 0 1 8.9 16H5a3 3 0 0 1-1-5.8V10a3 3 0 0 1 6 0Z",key:"1l6gj6"}],["path",{d:"M7 16v6",key:"1a82de"}],["path",{d:"M13 19v3",key:"13sx9i"}],["path",{d:"M12 19h8.3a1 1 0 0 0 .7-1.7L18 14h.3a1 1 0 0 0 .7-1.7L16 9h.2a1 1 0 0 0 .8-1.7L13 3l-1.4 1.5",key:"1sj9kv"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $1=a("Video",[["path",{d:"m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5",key:"ftymec"}],["rect",{x:"2",y:"6",width:"14",height:"12",rx:"2",key:"158x01"}]]),t={Accessibility:c1,Activity:I1,Archive:j1,Award:D1,Baby:z1,BadgeCheck:o,Banknote:P1,BarChart3:b1,BedDouble:Z,Beef:V1,BookOpen:j,Boxes:T1,Briefcase:D,Building:A1,Building2:z,Bus:U1,Calculator:B1,Calendar:w1,CalendarDays:H1,Camera:g1,Car:x1,CheckCheck:P,CheckCircle2:b,Church:q1,Clock:S1,Coins:n,Compass:L1,CreditCard:u1,Cross:G1,DoorOpen:W,Droplet:E1,Droplets:y,Drumstick:W1,Eye:v1,FileCheck2:r,Flame:C1,Gift:M1,Globe:l1,Globe2:f1,GraduationCap:d,Hammer:n1,HandCoins:V,HandHeart:T,Handshake:Z1,Heart:A,HeartHandshake:y1,HeartPulse:d1,Home:k1,Hospital:h1,Image:i1,Info:B,Landmark:p1,Laptop:m1,Layers:s1,Leaf:e1,Lightbulb:t1,ListChecks:o1,Mail:w,Map:O1,MapPin:h,Megaphone:r1,Moon:a1,Newspaper:F1,Package:$,PenTool:N1,Pencil:Y,Phone:H,PhoneCall:_,PiggyBank:R1,Recycle:X,Scale:Q,School:J1,Shield:K,ShieldAlert:J,ShieldCheck:g,Shirt:R,Smartphone:N,Soup:K1,Sparkles:s,Sprout:x,Star:F,Stethoscope:k,Sun:O,Syringe:Q1,Target:S,Tent:X1,Thermometer:E,Timer:_1,Trees:Y1,TrendingUp:G,Trophy:L,Truck:q,User:u,Users:U,Utensils:c,UtensilsCrossed:I,Video:$1,Wallet:v,Wheat:C,Wind:M,Zap:l},aa={certificate:o,license:o,verified:o,finance:r,audit:r,accounting:r,report:r,location:h,money:n,health:k,education:d,food:c,water:y};function k2(e){if(!e)return s;const m=t[e];if(m)return m;const p=e.toLowerCase().replace(/[-_\s]/g,""),i=Object.keys(t).find(f=>f.toLowerCase()===p);return i?t[i]:aa[p]??s}function d2(){return Object.keys(t).sort()}export{k2 as a,d2 as g};
