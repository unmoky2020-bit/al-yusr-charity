const o="/assets/axis-food-D5Nx6OUr.jpg";export{o as i};
