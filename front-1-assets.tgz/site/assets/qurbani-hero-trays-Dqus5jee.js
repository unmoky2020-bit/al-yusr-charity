const s="/assets/qurbani-hero-trays-CVFkAqZt.webp";export{s as h};
