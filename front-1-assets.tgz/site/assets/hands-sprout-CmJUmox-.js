const s="/assets/hands-sprout-BwxCXxGM.jpg";export{s as h};
