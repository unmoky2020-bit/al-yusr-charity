import{cc as t,bd as n}from"./index-DWVO5E7w.js";function m({className:e,...s}){return t.jsx("div",{className:n("animate-pulse rounded-md bg-muted",e),...s})}export{m as S};
