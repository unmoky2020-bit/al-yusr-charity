const s="/assets/axis-health-F31rl6mT.jpg";export{s as i};
