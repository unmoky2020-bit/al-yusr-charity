const r="/assets/markoun-poster-furniture-Dhk4wgIJ.webp";export{r as m};
