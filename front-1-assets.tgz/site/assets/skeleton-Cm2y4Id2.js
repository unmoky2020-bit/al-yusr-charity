import{cb as t,bd as n}from"./index-JJbt3h9W.js";function m({className:e,...s}){return t.jsx("div",{className:n("animate-pulse rounded-md bg-muted",e),...s})}export{m as S};
