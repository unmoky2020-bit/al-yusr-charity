const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/jspdf.es.min-mb_OgWhW.js","assets/index-DHqgRto2.js","assets/index-DEO5m15C.css"])))=>i.map(i=>d[i]);
import{aR as z,cq as N,ab as j,dk as I,cH as C,cc as e,aA as S,s as $,m as R,_ as F,c$ as L,bK as G}from"./index-DHqgRto2.js";import{D as M}from"./download-DUlMOK4z.js";const m=t=>String(t??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;");function _(t){return t?String(t).trim().replace(/\(([^)]+)\)/g,'<span dir="ltr" style="unicode-bidi: isolate; display: inline-block;">($1)</span>'):""}function E(t){const l=Math.floor(Math.abs(t||0));if(l===0)return"صفر جنيه مصري";const g=["","واحد","اثنان","ثلاثة","أربعة","خمسة","ستة","سبعة","ثمانية","تسعة"],d=["","عشرة","عشرون","ثلاثون","أربعون","خمسون","ستون","سبعون","ثمانون","تسعون"],r=["عشرة","أحد عشر","اثنا عشر","ثلاثة عشر","أربعة عشر","خمسة عشر","ستة عشر","سبعة عشر","ثمانية عشر","تسعة عشر"],i=["","مائة","مائتان","ثلاثمائة","أربعمائة","خمسمائة","ستمائة","سبعمائة","ثمانمائة","تسعمائة"];function o(u){let n="";const f=Math.floor(u/100),p=u%100,a=Math.floor(p/10),v=p%10;return f>0&&(n+=i[f]),p>0&&(n&&(n+=" و"),p>=10&&p<=19?n+=r[p-10]:v>0?(n+=g[v],a>0&&(n+=" و"+d[a])):a>0&&(n+=d[a])),n}const c=Math.floor(l/1e6),x=Math.floor(l%1e6/1e3),h=l%1e3,s=[];return c>0&&(c===1?s.push("مليون"):c===2?s.push("مليونان"):c>=3&&c<=10?s.push(o(c)+" ملايين"):s.push(o(c)+" مليون")),x>0&&(x===1?s.push("ألف"):x===2?s.push("ألفان"):x>=3&&x<=10?s.push(o(x)+" آلاف"):s.push(o(x)+" ألف")),h>0&&s.push(o(h)),`فقط ${s.join(" و")} جنيهًا مصريًا لا غير`}async function K(t){try{const g=await(await fetch(t)).blob();return await new Promise(d=>{const r=new FileReader;r.onloadend=()=>{typeof r.result=="string"&&r.result.startsWith("data:")?d(r.result):d(t)},r.onerror=()=>d(t),r.readAsDataURL(g)})}catch{return t}}async function U(t){const[{default:l},{jsPDF:g}]=await Promise.all([z(()=>import("./html2canvas.esm-BfxBtG_O.js"),[]),z(()=>import("./jspdf.es.min-mb_OgWhW.js").then(a=>a.j),__vite__mapDeps([0,1,2]))]);if(typeof document<"u"&&document.fonts)try{await Promise.race([document.fonts.ready,new Promise(a=>setTimeout(a,400))])}catch{}let d=N;try{d=await Promise.race([K(N),new Promise(a=>setTimeout(()=>a(N),500))])}catch{d=N}const r=document.createElement("div");r.id="alyusr-pdf-voucher-container",r.style.position="fixed",r.style.left="-10000px",r.style.top="-10000px",r.style.width="794px",r.style.height="1123px",r.style.zIndex="-999999",r.style.opacity="0",r.style.pointerEvents="none",r.style.backgroundColor="#ffffff",r.style.color="#0f172a",r.style.fontFamily="'DIN Next Arabic', 'Droid Arabic Kufi', 'TWK Lausanne', system-ui, -apple-system, sans-serif",r.style.boxSizing="border-box",r.style.padding="0",r.style.margin="0";const i=new Date(t.createdAt||Date.now()),o=i.toLocaleDateString("ar-EG",{year:"numeric",month:"long",day:"numeric"}),c=i.toLocaleTimeString("ar-EG",{hour:"2-digit",minute:"2-digit",second:"2-digit"}),x=Number(t.amount||0).toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2}),h=E(t.amount||0),s=String(t.status||"").toLowerCase(),u=s==="paid"||s==="completed"||s==="succeeded"||s==="success"||s==="approved",f=(Array.isArray(t.items)&&t.items.length>0?t.items:[{title:t.programTitle||"كفالة البرامج العامة والمساعدات",category:t.targetType||"برنامج خيري معتمد",quantity:1,amount:Number(t.amount||0)}]).map((a,v)=>{const k=a.title||a.name||a.name_ar||a.title_ar||a.program_name||a.item_name||a.description||t.programTitle||"كفالة البرامج العامة والمساعدات",A=a.category||a.type||a.targetType||t.targetType||"برنامج خيري معتمد",D=a.quantity||a.qty||1,T=Number(a.amount||a.total||t.amount||0);return`
    <tr style="border-bottom: 1px solid #f1f5f9;">
      <td style="padding: 9px 8px; text-align: center; color: #64748b; font-weight: 800; font-family: 'DIN Next Arabic', 'Droid Arabic Kufi', sans-serif;">${v+1}</td>
      <td style="padding: 9px 12px; font-weight: 900; color: #0f172a; direction: rtl; text-align: right; font-family: 'DIN Next Arabic', 'Droid Arabic Kufi', sans-serif;">${m(k)}</td>
      <td style="padding: 9px 12px; text-align: center;">
        <span style="display: inline-block; background: #ecfdf5; border: 1.5px solid #a7f3d0; color: #047857; font-weight: 800; font-size: 11px; padding: 3px 12px; border-radius: 6px; font-family: 'DIN Next Arabic', 'Droid Arabic Kufi', sans-serif;">
          ${m(A)}
        </span>
      </td>
      <td style="padding: 9px 8px; text-align: center; font-weight: 800; color: #334155; font-family: 'DIN Next Arabic', 'Droid Arabic Kufi', sans-serif;">${m(D)}</td>
      <td style="padding: 9px 12px; text-align: left; direction: ltr; font-weight: 900; color: #064e3b; font-family: 'DIN Next Arabic', 'Droid Arabic Kufi', sans-serif;">${T.toLocaleString("en-US",{minimumFractionDigits:2})} ج.م</td>
    </tr>
  `}).join(""),p=t.notes?`
    <div style="background: #f8fafc; padding: 9px 14px; border-top: 1px dashed #cbd5e1; font-size: 11px; color: #475569; direction: rtl; text-align: right;">
      <strong style="color: #064e3b; font-weight: 900;">ملاحظات وتوجيهات المتبرع:</strong>
      <span style="display: inline-block; unicode-bidi: isolate; margin-right: 6px; font-weight: 700;">${_(m(t.notes))}</span>
    </div>
  `:"";r.innerHTML=`
    <style>
      @font-face {
        font-family: 'DIN Next Arabic';
        src: url('/fonts/DINNextLTArabic-Bold.woff2') format('woff2');
        font-weight: 700 900;
        font-style: normal;
        font-display: swap;
      }
      @font-face {
        font-family: 'Droid Arabic Kufi';
        src: url('/fonts/DroidArabicKufi.woff2') format('woff2');
        font-weight: 600 900;
        font-display: swap;
      }
      @font-face {
        font-family: 'TWK Lausanne';
        src: url('/fonts/TWKLausanne-650.woff2') format('woff2');
        font-weight: 600 700;
        font-style: normal;
        font-display: swap;
      }

      #alyusr-pdf-root, #alyusr-pdf-root * {
        box-sizing: border-box !important;
        letter-spacing: normal !important;
        font-family: 'DIN Next Arabic', 'Droid Arabic Kufi', 'TWK Lausanne', system-ui, -apple-system, sans-serif !important;
      }
      .card-box {
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        padding: 8px 14px;
        box-sizing: border-box;
      }
      .card-title-ar {
        font-size: 11px;
        font-weight: 800;
        color: #64748b;
        text-align: right;
        direction: rtl;
      }
      .card-title-en {
        font-size: 8.5px;
        font-weight: 800;
        color: #94a3b8;
        text-align: left;
        direction: ltr;
        text-transform: uppercase;
        letter-spacing: 0.5px;
      }
      .card-value {
        font-size: 13.5px;
        font-weight: 900;
        color: #0f172a;
        margin-top: 3px;
      }
    </style>

    <div id="alyusr-pdf-root" style="width: 794px; height: 1123px; padding: 18px; background: #ffffff; box-sizing: border-box; overflow: hidden; margin: 0 auto;">
      
      <!-- الإطار الخارجي المزدوج الفاخر باللون الأخضر الزمردي المتناسق مع هوية المؤسسة -->
      <div style="border: 2px solid #059669; border-radius: 18px; padding: 5px; height: 1087px; box-sizing: border-box; background: #ffffff;">
        
        <!-- الإطار الداخلي الناعم الموزع بانتظام تام -->
        <div style="border: 1px solid #a7f3d0; border-radius: 14px; padding: 22px 24px 18px 24px; height: 1075px; box-sizing: border-box; background: #ffffff; display: flex; flex-direction: column; justify-content: space-between;">
          
          <!-- القسم الأول: الهيدر الرسمي وشارة الاعتماد ورقم الإيصال -->
          <div style="margin-bottom: 14px;">
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <!-- اليمين: الشعار واسم المؤسسة -->
                <td style="vertical-align: middle; text-align: right; direction: rtl; width: 62%;">
                  <table style="border-collapse: collapse; display: inline-table;">
                    <tr>
                      <td style="vertical-align: middle; padding-left: 14px;">
                        <img src="${d}" alt="Al-Yusr" style="width: 60px; height: 60px; object-fit: contain; border-radius: 50%; border: 1.5px solid #a7f3d0; padding: 1px; background: #ffffff;" />
                      </td>
                      <td style="vertical-align: middle; text-align: right; direction: rtl;">
                        <div style="font-size: 21px; font-weight: 900; color: #064e3b; line-height: 1.2;">مؤسسة اليسر الخيرية</div>
                        <div style="font-size: 11px; color: #64748b; font-weight: 700; margin-top: 3px;">
                          مشهرة برقم 2665 لسنة 2019 — وزارة التضامن الاجتماعي
                        </div>
                      </td>
                    </tr>
                  </table>
                </td>

                <!-- اليسار: شارة إيصال رسمي معتمد ورقم الإيصال -->
                <td style="vertical-align: middle; text-align: left; direction: ltr; width: 38%;">
                  <div style="display: inline-block; background: #ecfdf5; border: 1.5px solid #a7f3d0; color: #047857; padding: 5px 16px; border-radius: 20px; font-size: 11.5px; font-weight: 900; text-align: center; white-space: nowrap;">
                    إيصال رسمي معتمد
                  </div>
                  <div style="margin-top: 5px;">
                    <div style="font-size: 9.5px; color: #64748b; font-weight: 800;">رقم الإيصال / Receipt No:</div>
                    <div style="font-size: 14px; font-weight: 900; color: #064e3b; letter-spacing: 0.5px; margin-top: 1px;">${m(t.ref)}</div>
                  </div>
                </td>
              </tr>
            </table>
          </div>

          <!-- القسم الثاني: عنوان الإيصال التوثيقي -->
          <div style="text-align: center; margin-bottom: 14px; padding: 6px 0; border-top: 1px solid #f1f5f9; border-bottom: 1px solid #f1f5f9;">
            <div style="font-size: 18px; font-weight: 900; color: #064e3b; line-height: 1.3;">
              إيصال التبرع الإلكتروني المعتمد
            </div>
            <div style="font-size: 10.5px; color: #64748b; font-weight: 700; margin-top: 2px; direction: ltr;">
              Electronic Proof of Donation — Verified Document
            </div>
          </div>

          <!-- القسم الثالث: بطاقة المبلغ الرئيسية الفاخرة (الجرين كارد الزمردي) -->
          <div style="background: linear-gradient(135deg, #064e3b 0%, #047857 55%, #059669 100%); border-radius: 16px; padding: 16px 20px; margin-bottom: 14px; color: #ffffff;">
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <!-- تفاصيل المبلغ والأرقام والتفقيط -->
                <td style="text-align: right; direction: rtl; vertical-align: middle;">
                  <div style="font-size: 11.5px; font-weight: 800; color: #d1fae5; margin-bottom: 2px;">
                    إجمالي مبلغ التبرع
                  </div>
                  <div style="margin-top: 2px; direction: rtl; text-align: right;">
                    <span style="font-size: 30px; font-weight: 900; color: #ffffff; line-height: 1;">${x}</span>
                    <span style="font-size: 14.5px; font-weight: 800; color: #a7f3d0; margin-right: 8px;">جنيه مصري</span>
                  </div>
                  <div style="font-size: 11.5px; font-weight: 800; color: #ecfdf5; margin-top: 4px; line-height: 1.4;">
                    ${h}
                  </div>
                </td>

                <!-- بطاقة حالة العملية المعتمدة في الجهة المقابلة -->
                <td style="text-align: left; vertical-align: middle; width: 160px;">
                  <div style="background: rgba(255, 255, 255, 0.15); border: 1.5px solid rgba(255, 255, 255, 0.35); border-radius: 12px; padding: 10px 14px; text-align: center;">
                    <div style="font-size: 10px; font-weight: 800; color: #d1fae5; margin-bottom: 2px;">حالة العملية</div>
                    <div style="font-size: 13px; font-weight: 900; color: #6ee7b7; margin-top: 2px;">
                      ${u?"معتمد ومكتمل":"قيد المراجعة"}
                    </div>
                    <div style="font-size: 8.5px; font-weight: 800; color: #ffffff; margin-top: 2px; text-transform: uppercase; letter-spacing: 0.8px;">
                      ${u?"COMPLETED":"PENDING"}
                    </div>
                  </div>
                </td>
              </tr>
            </table>
          </div>

          <!-- القسم الرابع: شبكة البطاقات الستة المنظمة 3x2 المطابقة تماماً للمعاينة على الشاشة -->
          <div style="margin-bottom: 14px;">
            <table style="width: 100%; border-collapse: separate; border-spacing: 8px;">
              <!-- 1. اسم المتبرع ورقم الهاتف -->
              <tr>
                <td style="width: 50%; padding: 0; vertical-align: top;">
                  <div class="card-box">
                    <table style="width: 100%; border-collapse: collapse;">
                      <tr>
                        <td class="card-title-ar">اسم المتبرع الكريم</td>
                        <td class="card-title-en">Donor Name</td>
                      </tr>
                    </table>
                    <div class="card-value" style="direction: rtl; text-align: right;">${m(t.donorName||"متبرع كريم")}</div>
                  </div>
                </td>
                <td style="width: 50%; padding: 0; vertical-align: top;">
                  <div class="card-box">
                    <table style="width: 100%; border-collapse: collapse;">
                      <tr>
                        <td class="card-title-ar">رقم الهاتف</td>
                        <td class="card-title-en">Phone</td>
                      </tr>
                    </table>
                    <div class="card-value" style="direction: ltr; text-align: right; font-family: 'DIN Next Arabic', sans-serif;">${m(t.donorPhone||"—")}</div>
                  </div>
                </td>
              </tr>

              <!-- 2. البرنامج المستهدف ووسيلة الدفع -->
              <tr>
                <td style="width: 50%; padding: 0; vertical-align: top;">
                  <div class="card-box">
                    <table style="width: 100%; border-collapse: collapse;">
                      <tr>
                        <td class="card-title-ar">البرنامج / المبادرة المستهدفة</td>
                        <td class="card-title-en">Target Program</td>
                      </tr>
                    </table>
                    <div class="card-value" style="color: #047857; direction: rtl; text-align: right;">${m(t.programTitle||"كفالة البرامج العامة والمساعدات")}</div>
                  </div>
                </td>
                <td style="width: 50%; padding: 0; vertical-align: top;">
                  <div class="card-box">
                    <table style="width: 100%; border-collapse: collapse;">
                      <tr>
                        <td class="card-title-ar">وسيلة الدفع المعتمدة</td>
                        <td class="card-title-en">Payment Method</td>
                      </tr>
                    </table>
                    <div class="card-value" style="text-transform: uppercase; direction: rtl; text-align: right;">${m(t.paymentMethod||"دفع إلكتروني")}</div>
                  </div>
                </td>
              </tr>

              <!-- 3. البريد الإلكتروني وتاريخ ووقت الإصدار -->
              <tr>
                <td style="width: 50%; padding: 0; vertical-align: top;">
                  <div class="card-box">
                    <table style="width: 100%; border-collapse: collapse;">
                      <tr>
                        <td class="card-title-ar">البريد الإلكتروني</td>
                        <td class="card-title-en">Email</td>
                      </tr>
                    </table>
                    <div class="card-value" style="font-size: 11.5px; direction: ltr; text-align: right; font-family: 'DIN Next Arabic', sans-serif;">${m(t.donorEmail||"—")}</div>
                  </div>
                </td>
                <td style="width: 50%; padding: 0; vertical-align: top;">
                  <div class="card-box">
                    <table style="width: 100%; border-collapse: collapse;">
                      <tr>
                        <td class="card-title-ar">تاريخ ووقت الإصدار</td>
                        <td class="card-title-en">Issue Date</td>
                      </tr>
                    </table>
                    <div class="card-value" style="font-size: 11.5px; direction: rtl; text-align: right;">${o} — ${c}</div>
                  </div>
                </td>
              </tr>
            </table>
          </div>

          <!-- القسم الخامس: جدول بنود وتفاصيل التبرع والبرامج بالتفصيل الكامل -->
          <div style="margin-bottom: 14px; border: 1.5px solid #cbd5e1; border-radius: 14px; overflow: hidden; background: #ffffff;">
            <table style="width: 100%; border-collapse: collapse; background: #f8fafc; border-bottom: 1px solid #e2e8f0;">
              <tr>
                <td style="padding: 7px 14px; font-size: 11.5px; font-weight: 900; color: #064e3b; direction: rtl; text-align: right;">
                  تفاصيل وبنود التبرع المعتمدة
                </td>
                <td style="padding: 7px 14px; font-size: 9px; font-weight: 800; color: #64748b; direction: ltr; text-align: left; text-transform: uppercase;">
                  Itemized Allocation Details
                </td>
              </tr>
            </table>
            <table style="width: 100%; border-collapse: collapse; font-size: 11px; direction: rtl; text-align: right;">
              <thead>
                <tr style="background: #f1f5f9; border-bottom: 1.5px solid #cbd5e1; color: #475569; font-weight: 800; font-size: 10px;">
                  <th style="padding: 7px 8px; width: 34px; text-align: center;">#</th>
                  <th style="padding: 7px 12px; text-align: right;">البند / البرنامج المستهدف</th>
                  <th style="padding: 7px 12px; width: 150px; text-align: center;">التصنيف</th>
                  <th style="padding: 7px 8px; width: 50px; text-align: center;">العدد</th>
                  <th style="padding: 7px 12px; width: 125px; text-align: left; direction: ltr;">المبلغ</th>
                </tr>
              </thead>
              <tbody>
                ${f}
              </tbody>
              <tfoot>
                <tr style="background: #ecfdf5; border-top: 1.5px solid #a7f3d0; font-weight: 900; color: #064e3b;">
                  <td colspan="4" style="padding: 8px 12px; text-align: right;">إجمالي التبرع المعتمد بالجنيه المصري:</td>
                  <td style="padding: 8px 12px; text-align: left; direction: ltr; font-size: 12.5px;">${x} ج.م</td>
                </tr>
              </tfoot>
            </table>
            ${p}
          </div>

          <!-- القسم السادس: التوثيق الرسمي والختم المعتمد -->
          <div style="background: #f0fdf4; border: 1.5px solid #bbf7d0; border-radius: 14px; padding: 12px 18px; margin-bottom: 14px;">
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <!-- النص القانوني المعتمد -->
                <td style="vertical-align: middle; text-align: right; direction: rtl; padding-left: 14px;">
                  <div style="margin-bottom: 3px;">
                    <span style="font-size: 12px; font-weight: 900; color: #064e3b;">توثيق رسمي وقانوني</span>
                  </div>
                  <div style="font-size: 10px; color: #334155; line-height: 1.6; font-weight: 700;">
                    هذا الإيصال معتمد إلكترونيًا من مؤسسة اليسر الخيرية ولا يحتاج إلى توقيع خطي، وهو مسجل رسميًا في السجلات المالية للمؤسسة بموجب ترخيص وزارة التضامن الاجتماعي رقم 2665 لسنة 2019.
                  </div>
                </td>

                <!-- الختم الإلكتروني الرسمي المعتمد لمؤسسة اليسر بنفس خط وهوية الموقع عبر SVG المدعوم 100% -->
                <td style="vertical-align: middle; text-align: center; width: 85px;">
                  <svg width="84" height="84" viewBox="0 0 100 100" style="display: block; margin: 0 auto;">
                    <!-- الإطار الخارجي المنقط -->
                    <circle cx="50" cy="50" r="46" fill="#ffffff" stroke="#047857" stroke-width="2" stroke-dasharray="4 2" />
                    <!-- الإطار الداخلي الناعم -->
                    <circle cx="50" cy="50" r="41" fill="#ecfdf5" stroke="#059669" stroke-width="1.2" />
                    <!-- نصوص الختم الرسمية المعتمدة -->
                    <text x="50" y="27" text-anchor="middle" font-family="'DIN Next Arabic', 'Droid Arabic Kufi', sans-serif" font-size="8.5" font-weight="900" fill="#047857">مؤسسة اليسر</text>
                    <line x1="24" y1="32" x2="76" y2="32" stroke="#10b981" stroke-width="0.8" />
                    <text x="50" y="53" text-anchor="middle" font-family="'DIN Next Arabic', 'Droid Arabic Kufi', sans-serif" font-size="14.5" font-weight="900" fill="#064e3b">مُعْتَمَدْ</text>
                    <line x1="24" y1="59" x2="76" y2="59" stroke="#10b981" stroke-width="0.8" />
                    <text x="50" y="71" text-anchor="middle" font-family="'DIN Next Arabic', 'Droid Arabic Kufi', sans-serif" font-size="8.5" font-weight="900" fill="#047857">2019 / 2665</text>
                    <text x="50" y="82" text-anchor="middle" font-family="'DIN Next Arabic', 'Droid Arabic Kufi', sans-serif" font-size="6.5" font-weight="800" fill="#059669">وزارة التضامن</text>
                  </svg>
                </td>
              </tr>
            </table>
          </div>

          <!-- القسم السابع والأخير: الفوتر الرسمي المتناسق في أسفل الإيصال -->
          <div style="border-top: 1.5px solid #e2e8f0; padding-top: 10px; text-align: center;">
            <div style="font-size: 11px; font-weight: 900; color: #064e3b; margin-bottom: 2px;">
              مؤسسة اليسر الخيرية — معًا نوصل صدقتك إلى من يستحقها
            </div>
            <div style="font-size: 9px; font-weight: 700; color: #64748b;">
              المقر الرئيسي: المنصورة، الدقهلية، جمهورية مصر العربية | هاتف: ${m(j.phoneDisplay)} | https://elyusr.org
            </div>
            <div style="font-size: 8px; color: #94a3b8; margin-top: 3px; direction: ltr; font-weight: 600;">
              Transaction ID: ${m(t.ref)} • Electronic Proof of Donation • Al-Yusr Financial Core System
            </div>
          </div>

        </div>
      </div>
    </div>
  `,document.body.appendChild(r),await new Promise(a=>setTimeout(a,150));try{const v=(await l(r,{scale:2,useCORS:!0,allowTaint:!1,backgroundColor:"#ffffff",logging:!1,width:794,height:1123,windowWidth:794,windowHeight:1123,x:0,y:0,scrollX:0,scrollY:0,onclone:(y,w)=>{w.style.position="static",w.style.left="0px",w.style.top="0px",w.style.opacity="1",w.style.visibility="visible",y.defaultView?.scrollTo(0,0),y.documentElement&&(y.documentElement.scrollTop=0,y.documentElement.scrollLeft=0),y.body&&(y.body.scrollTop=0,y.body.scrollLeft=0)}})).toDataURL("image/jpeg",.98),k=new g({orientation:"portrait",unit:"mm",format:"a4",compress:!0});k.addImage(v,"JPEG",0,0,210,297);const A=k.output("blob"),D=URL.createObjectURL(new Blob([A],{type:"application/pdf"})),P=`alyusr-receipt-${String(t.ref||"receipt").trim().replace(/[^a-zA-Z0-9_-]/g,"_")}.pdf`,b=document.createElement("a");b.style.display="none",b.href=D,b.setAttribute("download",P),b.download=P,document.body.appendChild(b),b.click(),setTimeout(()=>{b.parentNode&&b.parentNode.removeChild(b),URL.revokeObjectURL(D)},2e3)}finally{r.parentNode&&r.parentNode.removeChild(r)}}const q=({d:t})=>{const{lang:l}=I(),[g,d]=C.useState(!1),r=async()=>{try{d(!0),await U({ref:t.ref,amount:t.amount,donorName:t.donor?.name||"متبرع كريم",donorEmail:t.donor?.email||"",donorPhone:t.donor?.phone||"",programTitle:t.programLabel||t.program||"صدقة جارية عامة",paymentMethod:t.method||"دفع إلكتروني",status:t.status||"completed",createdAt:t.createdAt,targetType:t.targetType,items:t.items,notes:t.notes||t.note}),L({title:l==="ar"?"تم تحميل إيصال PDF الرسمي بنجاح":"Official PDF Receipt downloaded",description:l==="ar"?"المستند معتمد إلكترونياً بهوية مؤسسة اليسر":"Receipt is electronically certified"})}catch(f){L({title:l==="ar"?"خطأ في إنشاء ملف PDF":"PDF generation failed",description:G(f),variant:"destructive"})}finally{d(!1)}},i=l==="ar",o=i?{title:"إيصال التبرع الإلكتروني المعتمد",subTitleEn:"Electronic Proof of Donation — Verified Document",foundationName:"مؤسسة اليسر الخيرية",regText:"مشهرة برقم 2665 لسنة 2019 — وزارة التضامن الاجتماعي",officialBadge:"إيصال رسمي معتمد",receiptNo:"رقم الإيصال / Receipt No:",amountPaid:"المبلغ الإجمالي المتبرع به",statusLabel:"حالة العملية",completed:"معتمد ومكتمل",donorName:"اسم المتبرع الكريم",phone:"رقم هاتف المتبرع",program:"البرنامج / المبادرة المستهدفة",method:"وسيلة الدفع المعتمدة",email:"البريد الإلكتروني",issueDate:"تاريخ ووقت الإصدار",legalTitle:"توثيق رسمي وقانوني",legalNote:"هذا الإيصال مُعتمد إلكترونياً من قبل مؤسسة اليسر الخيرية ولا يحتاج إلى توقيع خطي، ومسجل رسمياً بالسجلات المالية للمؤسسة بموجب ترخيص وزارة التضامن الاجتماعي رقم 2665 لسنة 2019.",footerMoto:"مؤسسة اليسر الخيرية — معاً نصل بصدقتك لمن يستحق",footerContact:`المقر الرئيسي: المنصورة، الدقهلية، جمهورية مصر العربية | هاتف: ${j.phoneDisplay} | https://elyusr.org`,download:"تحميل إيصال PDF",downloading:"جارٍ إنشاء ملف PDF..."}:{title:"Certified Electronic Donation Receipt",subTitleEn:"Electronic Proof of Donation — Verified Document",foundationName:"Al-Yusr Charity Foundation",regText:"Registered NGO #2665 (2019) — Ministry of Social Solidarity",officialBadge:"OFFICIAL RECEIPT",receiptNo:"Receipt No:",amountPaid:"Total Amount Paid",statusLabel:"Status",completed:"COMPLETED",donorName:"Donor Name",phone:"Phone Number",program:"Target Program / Initiative",method:"Payment Method",email:"Email Address",issueDate:"Issue Date & Time",legalTitle:"Official Legal Certification",legalNote:"This official electronic receipt is issued and verified by Al-Yusr Charity Foundation under license #2665/2019, and requires no manual signature.",footerMoto:"Al-Yusr Charity Foundation — Reaching Those in Need Together",footerContact:`HQ: Mansoura, Dakahlia, Egypt | Tel: ${j.phoneE164} | https://elyusr.org`,download:"Download PDF Receipt",downloading:"Generating PDF..."},c=t.status?.toLowerCase()==="completed"||t.status?.toLowerCase()==="paid",x=E(t.amount),h=new Date(t.createdAt||Date.now()),s=h.toLocaleDateString(i?"ar-EG":"en-US",{year:"numeric",month:"long",day:"numeric"}),u=h.toLocaleTimeString(i?"ar-EG":"en-US",{hour:"2-digit",minute:"2-digit",second:"2-digit"}),n=t.items&&t.items.length>0?t.items:[{title:t.programLabel||t.program||(i?"مساهمة في البرامج الخيرية العامة":"General Charity Contribution"),category:t.targetType||(i?"تبرع عام":"General Donation"),quantity:1,amount:t.amount}];return e.jsx("div",{className:"receipt-print-area rounded-2xl border-2 border-emerald-600/90 bg-card p-2 md:p-3 shadow-md",children:e.jsxs("div",{className:"rounded-xl border border-emerald-300/80 bg-background/95 p-5 md:p-7 dark:border-emerald-800 dark:bg-card",children:[e.jsxs("div",{className:"flex flex-col sm:flex-row sm:items-center justify-between gap-3.5 sm:gap-4 border-b border-border/80 pb-4 sm:pb-5",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("div",{className:"relative flex h-12 w-12 sm:h-14 sm:w-14 shrink-0 items-center justify-center rounded-full border border-emerald-300 bg-white p-1 shadow-sm dark:border-emerald-700 dark:bg-card",children:e.jsx("img",{src:N,alt:"Al-Yusr Logo",className:"h-full w-full rounded-full object-contain"})}),e.jsxs("div",{children:[e.jsx("h2",{className:"text-lg sm:text-xl font-black text-emerald-950 dark:text-emerald-100",children:o.foundationName}),e.jsx("div",{className:"text-[10.5px] sm:text-[11px] font-semibold text-muted-foreground mt-0.5",children:o.regText})]})]}),e.jsxs("div",{className:"flex items-center sm:items-end justify-between sm:justify-start sm:flex-col gap-1.5 pt-2 sm:pt-0 border-t border-border/40 sm:border-0",children:[e.jsxs("span",{className:"inline-flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-3 py-1 text-xs font-black text-emerald-700 border border-emerald-500/25 dark:text-emerald-300",children:[e.jsx(S,{className:"h-3.5 w-3.5 text-emerald-600"}),e.jsx("span",{children:o.officialBadge})]}),e.jsxs("div",{className:"text-end sm:text-end",children:[e.jsx("div",{className:"text-[10px] font-bold text-muted-foreground",children:o.receiptNo}),e.jsx("div",{className:"font-mono text-xs sm:text-sm font-black text-emerald-900 dark:text-emerald-200",children:t.ref})]})]})]}),e.jsxs("div",{className:"my-5 border-y border-border/60 py-2.5 text-center",children:[e.jsx("h3",{className:"text-lg font-black text-emerald-950 dark:text-emerald-100 md:text-xl",children:o.title}),e.jsx("p",{className:"text-xs font-semibold text-muted-foreground mt-0.5",dir:"ltr",children:o.subTitleEn})]}),e.jsx("div",{className:"rounded-2xl p-4 sm:p-5 md:p-6 text-white shadow-md",style:{background:"linear-gradient(135deg, #064e3b 0%, #047857 55%, #059669 100%)"},children:e.jsxs("div",{className:"flex items-center justify-between gap-3 sm:gap-4",children:[e.jsxs("div",{className:"flex-1 min-w-0",children:[e.jsx("div",{className:"text-[11px] sm:text-xs font-bold text-emerald-200 mb-0.5",children:e.jsx("span",{children:o.amountPaid})}),e.jsxs("div",{className:"flex items-baseline gap-1.5 sm:gap-2",children:[e.jsx("span",{className:"font-sans text-2xl sm:text-3xl md:text-4xl font-black text-white tracking-tight",children:t.amount.toLocaleString("en-US",{minimumFractionDigits:2})}),e.jsx("span",{className:"text-xs sm:text-sm font-extrabold text-emerald-200",children:i?"جنيه مصري":"EGP"})]}),e.jsx("div",{className:"mt-1 text-[10.5px] sm:text-xs font-bold text-emerald-100 leading-snug",children:x})]}),e.jsxs("div",{className:"shrink-0 rounded-xl border border-white/25 bg-white/12 px-3 sm:px-4 py-2.5 sm:py-3 text-center backdrop-blur-sm min-w-[120px] sm:min-w-[155px]",children:[e.jsx("div",{className:"text-[10px] sm:text-[11px] font-bold text-emerald-200",children:o.statusLabel}),e.jsxs("div",{className:"mt-1 flex items-center justify-center gap-1.5 text-xs sm:text-sm font-black text-emerald-300",children:[e.jsx($,{className:"h-3.5 w-3.5 sm:h-4 sm:w-4 text-emerald-300 shrink-0"}),e.jsx("span",{children:c?o.completed:"قيد المراجعة"})]}),e.jsx("div",{className:"text-[9px] sm:text-[9.5px] font-bold text-white/80 font-mono tracking-wider uppercase mt-0.5",children:c?"COMPLETED":"PENDING"})]})]})}),e.jsxs("div",{className:"mt-5 grid grid-cols-1 md:grid-cols-2 gap-3 text-xs",children:[e.jsxs("div",{className:"rounded-xl border border-border/80 bg-muted/20 p-3.5 flex flex-col justify-center",children:[e.jsxs("div",{className:"flex items-center justify-between text-[11px] font-bold text-muted-foreground",children:[e.jsx("span",{children:o.donorName}),e.jsx("span",{dir:"ltr",className:"text-[9px] uppercase font-bold tracking-wider text-muted-foreground/70",children:"Donor Name"})]}),e.jsx("div",{className:"mt-1 font-black text-foreground text-sm",children:t.donor.name||(i?"متبرع كريم":"Kind Donor")})]}),e.jsxs("div",{className:"rounded-xl border border-border/80 bg-muted/20 p-3.5 flex flex-col justify-center",children:[e.jsxs("div",{className:"flex items-center justify-between text-[11px] font-bold text-muted-foreground",children:[e.jsx("span",{children:o.phone}),e.jsx("span",{dir:"ltr",className:"text-[9px] uppercase font-bold tracking-wider text-muted-foreground/70",children:"Phone"})]}),e.jsx("div",{className:"mt-1 font-black text-foreground text-sm",dir:"ltr",style:{textAlign:i?"right":"left"},children:t.donor.phone||"—"})]}),e.jsxs("div",{className:"rounded-xl border border-border/80 bg-muted/20 p-3.5 flex flex-col justify-center",children:[e.jsxs("div",{className:"flex items-center justify-between text-[11px] font-bold text-muted-foreground",children:[e.jsx("span",{children:o.program}),e.jsx("span",{dir:"ltr",className:"text-[9px] uppercase font-bold tracking-wider text-muted-foreground/70",children:"Program"})]}),e.jsx("div",{className:"mt-1 font-black text-emerald-700 dark:text-emerald-400 text-sm",children:t.programLabel||(i?"كفالة طالب علم":"General Cause")})]}),e.jsxs("div",{className:"rounded-xl border border-border/80 bg-muted/20 p-3.5 flex flex-col justify-center",children:[e.jsxs("div",{className:"flex items-center justify-between text-[11px] font-bold text-muted-foreground",children:[e.jsx("span",{children:o.method}),e.jsx("span",{dir:"ltr",className:"text-[9px] uppercase font-bold tracking-wider text-muted-foreground/70",children:"Payment Method"})]}),e.jsx("div",{className:"mt-1 font-black text-foreground uppercase text-sm",children:t.method||"VISA"})]}),e.jsxs("div",{className:"rounded-xl border border-border/80 bg-muted/20 p-3.5 flex flex-col justify-center",children:[e.jsxs("div",{className:"flex items-center justify-between text-[11px] font-bold text-muted-foreground",children:[e.jsx("span",{children:o.email}),e.jsx("span",{dir:"ltr",className:"text-[9px] uppercase font-bold tracking-wider text-muted-foreground/70",children:"Email"})]}),e.jsx("div",{className:"mt-1 font-bold text-foreground text-xs",dir:"ltr",style:{textAlign:i?"right":"left"},children:t.donor.email||"—"})]}),e.jsxs("div",{className:"rounded-xl border border-border/80 bg-muted/20 p-3.5 flex flex-col justify-center",children:[e.jsxs("div",{className:"flex items-center justify-between text-[11px] font-bold text-muted-foreground",children:[e.jsx("span",{children:o.issueDate}),e.jsx("span",{dir:"ltr",className:"text-[9px] uppercase font-bold tracking-wider text-muted-foreground/70",children:"Issue Date"})]}),e.jsxs("div",{className:"mt-1 font-bold text-foreground text-xs",children:[s," — ",u]})]})]}),e.jsxs("div",{className:"mt-5 rounded-xl border border-border/80 overflow-hidden bg-card",children:[e.jsxs("div",{className:"bg-emerald-950/5 dark:bg-emerald-500/10 px-4 py-2.5 border-b border-border/70 flex items-center justify-between",children:[e.jsx("span",{className:"text-xs font-black text-emerald-950 dark:text-emerald-100",children:i?"تفاصيل وبنود التبرع المعتمدة":"Itemized Donation Breakdown"}),e.jsx("span",{className:"text-[10px] font-bold text-muted-foreground",children:i?`${n.length} بند`:`${n.length} Item(s)`})]}),e.jsx("div",{className:"overflow-x-auto",children:e.jsxs("table",{className:"w-full text-right text-xs",children:[e.jsx("thead",{className:"bg-muted/40 text-[10.5px] font-bold text-muted-foreground border-b border-border/60",children:e.jsxs("tr",{children:[e.jsx("th",{className:"py-2 px-3 text-center w-10",children:"#"}),e.jsx("th",{className:"py-2 px-3",children:i?"البند / البرنامج المستهدف":"Item / Target Program"}),e.jsx("th",{className:"py-2 px-3 text-center",children:i?"التصنيف":"Category"}),e.jsx("th",{className:"py-2 px-3 text-center",children:i?"العدد":"Qty"}),e.jsx("th",{className:"py-2 px-3 text-left",children:i?"المبلغ":"Amount"})]})}),e.jsx("tbody",{className:"divide-y divide-border/40 text-foreground",children:n.map((f,p)=>e.jsxs("tr",{className:"hover:bg-muted/20",children:[e.jsx("td",{className:"py-2.5 px-3 text-center font-mono text-[11px] text-muted-foreground font-bold",children:p+1}),e.jsx("td",{className:"py-2.5 px-3 font-black text-foreground text-xs",children:f.title}),e.jsx("td",{className:"py-2.5 px-3 text-center",children:e.jsx("span",{className:"inline-block rounded-md bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 text-[10px] font-bold text-emerald-800 dark:text-emerald-300",children:f.category||t.targetType||(i?"مساهمة":"Donation")})}),e.jsx("td",{className:"py-2.5 px-3 text-center font-mono text-xs font-bold",children:f.quantity||1}),e.jsxs("td",{className:"py-2.5 px-3 text-left font-mono font-black text-xs text-emerald-700 dark:text-emerald-400",children:[Number(f.amount).toLocaleString("en-US",{minimumFractionDigits:2})," ",i?"ج.م":"EGP"]})]},p))}),e.jsx("tfoot",{className:"bg-emerald-950/5 dark:bg-emerald-500/10 border-t border-border font-black text-xs",children:e.jsxs("tr",{children:[e.jsx("td",{colSpan:4,className:"py-2.5 px-3 text-right text-emerald-950 dark:text-emerald-100",children:i?"الإجمالي الكلي المعتمد:":"Total Verified Donation:"}),e.jsxs("td",{className:"py-2.5 px-3 text-left font-mono font-black text-sm text-emerald-800 dark:text-emerald-300",children:[t.amount.toLocaleString("en-US",{minimumFractionDigits:2})," ",i?"ج.م":"EGP"]})]})})]})})]}),(t.notes||t.note)&&e.jsxs("div",{className:"mt-3 rounded-lg border border-border/70 bg-muted/20 p-3 text-xs",children:[e.jsx("span",{className:"font-black text-emerald-900 dark:text-emerald-200 block mb-1",children:i?"ملاحظات وتوجيهات المتبرع:":"Donor Notes & Instructions:"}),e.jsx("p",{className:"text-muted-foreground font-medium text-[11px] leading-relaxed",dir:"auto",children:e.jsx("bdi",{children:t.notes||t.note})})]}),e.jsx("div",{className:"mt-5 rounded-xl border border-emerald-300/70 bg-emerald-500/5 p-3.5 sm:p-4 dark:border-emerald-800/70",children:e.jsxs("div",{className:"flex items-center justify-between gap-3 sm:gap-4",children:[e.jsxs("div",{className:"flex-1 min-w-0",children:[e.jsx("div",{className:"text-xs sm:text-sm font-black text-emerald-950 dark:text-emerald-100",children:o.legalTitle}),e.jsx("p",{className:"text-[10.5px] sm:text-[11.5px] leading-relaxed text-muted-foreground font-medium mt-0.5",children:o.legalNote})]}),e.jsx("div",{className:"shrink-0 flex items-center justify-center ps-1 sm:ps-2",children:e.jsx("div",{className:"flex h-16 w-16 sm:h-20 sm:w-20 shrink-0 flex-col items-center justify-center rounded-full border-2 border-dashed border-emerald-600 bg-white p-1 text-emerald-800 shadow-xs dark:bg-emerald-950 dark:text-emerald-300",children:e.jsxs("div",{className:"flex h-full w-full flex-col items-center justify-center rounded-full border border-emerald-500 text-center p-0.5",children:[e.jsx("span",{className:"text-[6.5px] sm:text-[7.5px] font-black uppercase text-emerald-700 dark:text-emerald-400",children:"مؤسسة اليسر"}),e.jsx("span",{className:"text-[9px] sm:text-[11px] font-black leading-tight text-emerald-900 dark:text-emerald-200",children:"مُعْتَمَدْ"}),e.jsx("span",{className:"text-[6.5px] sm:text-[7.5px] font-bold font-mono text-emerald-600 dark:text-emerald-400",children:"2019 / 2665"})]})})})]})}),e.jsxs("div",{className:"mt-5 border-t border-border/80 pt-4 text-center text-xs text-muted-foreground",children:[e.jsx("div",{className:"font-black text-emerald-900 dark:text-emerald-200 text-xs",children:o.footerMoto}),e.jsxs("div",{className:"text-[10.5px] mt-0.5 flex flex-wrap items-center justify-center gap-1.5",children:[e.jsx("span",{children:i?"المقر الرئيسي: المنصورة، الدقهلية، جمهورية مصر العربية":"HQ: Mansoura, Dakahlia, Egypt"}),e.jsx("span",{children:"|"}),e.jsx("span",{children:i?`هاتف: ${j.phoneDisplay}`:`Tel: ${j.phoneE164}`}),e.jsx("span",{children:"|"}),e.jsx("a",{href:"https://elyusr.org/",target:"_blank",rel:"noopener noreferrer",className:"text-emerald-700 dark:text-emerald-400 font-bold hover:underline",children:"https://elyusr.org"})]}),e.jsxs("div",{className:"font-mono text-[9px] text-muted-foreground/70 mt-1",dir:"ltr",children:["Transaction ID: ",t.ref," • Generated via Al-Yusr Financial Core System"]})]}),e.jsx("div",{className:"no-print mt-6 flex flex-wrap items-center justify-end gap-3 border-t border-border pt-4",children:e.jsxs(R,{onClick:r,disabled:g,size:"sm",className:"gap-2 h-10 px-6 font-black text-white bg-emerald-700 hover:bg-emerald-800 shadow-md transition-all active:scale-95 text-xs",children:[g?e.jsx(F,{className:"h-4 w-4 animate-spin text-white"}):e.jsx(M,{className:"h-4 w-4 text-white"}),e.jsx("span",{children:g?o.downloading:o.download})]})})]})})};export{q as D};
