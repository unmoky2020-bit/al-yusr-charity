const s="/assets/markoun-poster-delivery-DcjtvdXs.png";export{s as m};
