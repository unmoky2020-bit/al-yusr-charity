const s="/assets/yusr-distribution-1-wdyHKpgj.webp";export{s as t};
