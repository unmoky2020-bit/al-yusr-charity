const s="/assets/ssd_mobilenetv1_model-weights_manifest-B7lFiDAh.json";export{s as default};
