import{cb as s,a7 as a}from"./index-CYtZctlB.js";const t=()=>s.jsx(a,{to:"/admin/users?tab=permissions",replace:!0});export{t as default};
