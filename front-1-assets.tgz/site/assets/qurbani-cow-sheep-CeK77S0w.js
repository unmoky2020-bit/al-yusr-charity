const e="/assets/qurbani-cow-sheep-CNNW1zRk.webp";export{e as q};
