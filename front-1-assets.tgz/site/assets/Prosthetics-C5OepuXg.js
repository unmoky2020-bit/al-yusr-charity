const s="/assets/Prosthetics-C_1yT1vW.jpg";export{s as p};
