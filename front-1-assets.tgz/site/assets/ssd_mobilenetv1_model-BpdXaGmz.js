const e="/assets/ssd_mobilenetv1_model-CwVKCpPc.bin";export{e as default};
