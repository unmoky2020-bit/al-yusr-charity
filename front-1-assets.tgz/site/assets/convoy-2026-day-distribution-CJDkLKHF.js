const o="/assets/convoy-2026-day-distribution-CenGCGPD.jpg";export{o as c};
