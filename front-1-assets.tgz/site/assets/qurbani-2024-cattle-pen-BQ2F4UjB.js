const s="/assets/brand-poster-classroom-D1bxnytU.webp",a="/assets/convoy-2026-pickup-loaded-Bz8JlLpk.jpg",o="/assets/qurbani-2024-cattle-pen-BEXZ1pgC.jpg";export{a,s as c,o as q};
