const a="/assets/takrim-van-D_clSIOd.jpg";export{a as t};
