const s="/assets/family-hope-D94AxSfE.webp";export{s as t};
