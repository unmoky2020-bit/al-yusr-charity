const s="/assets/axis-education-Bi5-u9sK.jpg";export{s as i};
