import{db as c,cH as o}from"./index-CedYTTif.js";import{d as r}from"./AdminLayout-eD7pI2aU.js";function u(){const{access:s}=c();return o.useCallback(a=>r(s,a),[s])}export{u};
