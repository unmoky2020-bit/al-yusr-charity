const e="/assets/poster-meat-vGy5oxjg.webp";export{e as m};
