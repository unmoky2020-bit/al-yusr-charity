const e="/assets/poster-bride-Bf2zE2LH.webp";export{e as b};
