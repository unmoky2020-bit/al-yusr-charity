function e(t){return t.replace(/[٠-٩]/g,r=>String(r.charCodeAt(0)-1632)).replace(/[۰-۹]/g,r=>String(r.charCodeAt(0)-1776))}function i(t){return e(t).replace(/\D/g,"")}export{i as d};
