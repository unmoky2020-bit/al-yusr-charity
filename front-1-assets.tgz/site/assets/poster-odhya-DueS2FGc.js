const s="/assets/poster-odhya-CT1OzZ0t.webp";export{s as p};
