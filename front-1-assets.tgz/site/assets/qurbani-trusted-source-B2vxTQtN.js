const s="/assets/qurbani-trusted-source-Ug4adRq8.webp";export{s as q};
