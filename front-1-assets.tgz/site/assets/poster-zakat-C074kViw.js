const s="/assets/poster-box-KhhWG36k.png",t="/assets/poster-volunteer-BRqjSsbq.png",o="/assets/poster-zakat-DwygLuN3.png";export{s as b,t as v,o as z};
