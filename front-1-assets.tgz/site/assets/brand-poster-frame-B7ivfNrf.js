const s="/assets/brand-poster-frame-csCGq1Bp.jpg";export{s as b};
