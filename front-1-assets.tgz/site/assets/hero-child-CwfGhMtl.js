const s="/assets/program-education-BR2rx34v.jpg",e="/assets/hero-child-BBZOXgwq.jpg";export{e as h,s as n};
