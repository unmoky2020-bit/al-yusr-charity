import{da as c,cG as o}from"./index-DubJx3Jl.js";import{d as r}from"./AdminLayout-CGaar-3q.js";function u(){const{access:s}=c();return o.useCallback(a=>r(s,a),[s])}export{u};
