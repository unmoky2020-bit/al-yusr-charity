import{cc as t,bd as n}from"./index-DHqgRto2.js";function m({className:e,...s}){return t.jsx("div",{className:n("animate-pulse rounded-md bg-muted",e),...s})}export{m as S};
