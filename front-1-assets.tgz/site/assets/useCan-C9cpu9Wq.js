import{da as c,cG as o}from"./index-JJbt3h9W.js";import{d as r}from"./AdminLayout-DH4dVGEG.js";function u(){const{access:s}=c();return o.useCallback(a=>r(s,a),[s])}export{u};
