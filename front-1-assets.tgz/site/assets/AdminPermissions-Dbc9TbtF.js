import{cb as s,a7 as a}from"./index-DubJx3Jl.js";const t=()=>s.jsx(a,{to:"/admin/users?tab=permissions",replace:!0});export{t as default};
